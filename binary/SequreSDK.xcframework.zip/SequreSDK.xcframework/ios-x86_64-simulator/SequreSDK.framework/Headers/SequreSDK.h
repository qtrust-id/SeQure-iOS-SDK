//
//  SequreSDK.h
//  SequreSDK
//
//  Created by IceQwen on 27/09/24.
//

#import <Foundation/Foundation.h>

//! Project version number for SequreSDK.
FOUNDATION_EXPORT double SequreSDKVersionNumber;

//! Project version string for SequreSDK.
FOUNDATION_EXPORT const unsigned char SequreSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SequreSDK/PublicHeader.h>
#import <SequreSDK/OpenCVWrapper.h>


